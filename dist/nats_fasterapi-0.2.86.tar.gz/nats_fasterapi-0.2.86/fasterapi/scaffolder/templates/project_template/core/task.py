 
from repositories.tokens_repo import delete_access_and_refresh_token_with_user_id



ASYNC_TASK_REGISTRY = {
 
    "delete_tokens":delete_access_and_refresh_token_with_user_id
    
}
